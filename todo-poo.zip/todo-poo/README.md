# Sistema de Gerenciamento de Tarefas (TODO) — CLI

Trabalho Avaliativo de Programação Orientada a Objetos (POO).

**Autor:** Arthur Gaspar de Souza

## Descrição

Sistema de linha de comando (CLI) para gerenciar uma lista de tarefas,
desenvolvido em Python aplicando os conceitos de Programação Orientada
a Objetos: classes, atributos, métodos, objetos e encapsulamento
(via `@property`).

## Funcionalidades

- Adicionar novas tarefas (título, descrição e prioridade)
- Listar todas as tarefas, separando pendentes de concluídas
- Marcar tarefas como concluídas
- Remover tarefas
- Persistência automática em arquivo `tarefas.json` (os dados
  continuam disponíveis entre execuções)
- **Extras:** busca de tarefa por título, ordenação por prioridade
  e um resumo estatístico (total, concluídas, pendentes)

## Estrutura do projeto

```
todo-poo/
├── main.py              # Interface de linha de comando (menu)
├── gerenciador.py        # Classe GerenciadorTarefas (regras de negócio + persistência)
├── models/
│   ├── __init__.py
│   └── tarefa.py          # Classe Tarefa (modelo de dados, encapsulamento)
├── tarefas.json          # Gerado automaticamente ao usar o sistema
└── README.md
```

## Conceitos de POO aplicados

- **Classes e objetos:** `Tarefa` e `GerenciadorTarefas`.
- **Encapsulamento:** atributos privados (`_titulo`, `_concluida`, etc.)
  acessados por meio de `@property`, com validação nos *setters*
  (ex.: título não pode ser vazio, prioridade só aceita valores válidos).
- **Abstração:** `main.py` não sabe como as tarefas são guardadas ou
  salvas — apenas chama métodos como `adicionar_tarefa()` ou
  `marcar_concluida()`, que escondem os detalhes de implementação.
- **Responsabilidade única:** cada classe/arquivo tem um papel claro
  (modelo de dados, regra de negócio, interface com o usuário).

## Como executar

Requer apenas Python 3 (nenhuma biblioteca externa é necessária).

```bash
python3 main.py
```

Use o menu numérico exibido no terminal para navegar entre as opções.

## Como entregar no GitHub

1. Crie um repositório novo no GitHub (ex.: `todo-poo`).
2. Dentro da pasta do projeto, rode:
   ```bash
   git init
   git add .
   git commit -m "Trabalho POO - Sistema de Tarefas (TODO)"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/todo-poo.git
   git push -u origin main
   ```
3. No GitHub, vá em **Settings > Collaborators** do repositório e
   adicione o usuário `guilherme-ferraz` como colaborador (ou deixe
   o repositório público, se for permitido pelo professor).
